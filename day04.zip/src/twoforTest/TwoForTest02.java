package twoforTest;

public class TwoForTest02 {
	public static void main(String[] args) {
		
		System.out.println("구구단");
		for (int i = 1; i <= 9; i++) {// 바깥 for문
			System.out.println(i+"단");
			for (int j = 1; j <= 9; j++) {// 안쪽 for문
				System.out.println(i + " x " + j + " = " + (i * j));
			}
		}
	}
}
