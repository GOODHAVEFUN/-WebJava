package forTest;

import java.util.Scanner;

public class ForTask {

	public static void main(String[] args) {
		// 1~100까지 출력
		System.out.println("1~100까지 출력");
		for (int i = 1; i <= 100; i++) {
			System.out.println(i + "번 출력");
		}
		// 100~1까지 출력 10씩 감소하돌록 출력
		System.out.println("100~1까지 출력 10씩 감소하돌록 출력");
		for (int i = 100; i >= 10; i -= 10) {
			System.out.println(i + "번 출력");
		}
		// 1부터 짝수만 출력
		System.out.println("1부터 짝수만 출력");
		for (int i = 1; i <= 100; i++) {
			if (i % 2 == 0) {
				System.out.println(i + "번 출력");
			}
		}
		// A~F까지 출력(char사용)
		System.out.println("A~F까지 출력(char사용)");
		for (char i = 'A'; i <= 'F'; i++) {
			System.out.print(i+"\n");
		}
		// 65~70까지 출력 (강제 형변환)
		System.out.println("65~70까지 출력 (강제 형변환)");
		for (char i = 'A'; i <= 'F'; i++) {
			System.out.println((int)i + " 출력");
		}
		
		//2부터 10까지의 숫자를 모두 곱한 결과를 출력
		//1)for문 쓰지않고
		System.out.println("2부터 10까지의 숫자를 모두 곱한 결과를 출력 1)for문 쓰지않고");
		
		System.out.println(2*3*4*5*6*7*8*9*10);
		
		//2)for문 사용
		System.out.println("2부터 10까지의 숫자를 모두 곱한 결과를 출력 2)for문 사용");
		int j=1;
		for (int i = 2; i <= 10; i++) {
			System.out.println(j+" x "+i+ " = ");
			j*= i;
			 System.out.println(j);
		}
		
		//사용자로부터 입력받은 정수에 대해 1부터 n까지 모두 더한 결과를 출력 for문없이
		Scanner sc = new Scanner(System.in);
		System.out.println("정수입력 : ");
		int num = sc.nextInt();
		
		
		
		
		//사용자로부터 입력받은 정수에 대해 1부터 n까지 모두 더한 결과를 출력for문사용
				Scanner sc1 = new Scanner(System.in);
				System.out.println("정수입력 : ");
				int num1 = sc1.nextInt();
				int total1 = 0;
				for (int i = 1; i < num1; i++) {
					total1 += num1;				}
				
				System.out.println("덧셈결과"+total1);
				

	}

}
