package forTest;

public class ForTest02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 1~100까지 중 짝수의 합 출력
		int total1 = 0;
		for (int i = 0; i <= 10; i++) {
			if (i % 2 == 0) {
				continue;
			}
			System.out.println(i);
			total1 += i;
		}
		System.out.println(total1);

//		for (int i = 1; i <= 10; i++) {
//			if (i == 3) {
//				continue;
//			}
//			System.out.println(i);
//		}
	}

}
