package forTest;

public class ForTest01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i < 10; i++) {
			System.out.println((i + 1) + "번.행복하다");
		}
		//10번부터 ~1번까지 반복
		for (int i = 10; i > 0; i--) {
			System.out.println(i + "번.행복하다");
		}
//		for (;true;) {
//			System.out.println("무한반복");
//		}
//		for (;false;) {
//			System.out.println("실행안됌");
//		}
	}

}
