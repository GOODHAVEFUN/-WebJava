package whileTest;

public class WhileTask {

	public static void main(String[] args) {
		// 1부터 100까지의 합, 짝수의 합 , 홀수의 합을 출력
		// 1부터 100까지의 합
		int cnt = 0;
		int total = 0;
		while (cnt != 100) {
			total += cnt;
			System.out.println(cnt + " + " + total + " = " + (cnt + total));
			cnt++;
		}
		System.out.println("1부터 100까지의 합 :" + total);

		// 1부터 100까지의 짝수의 합 출력
		cnt = 0;
		total = 0;
		while (cnt < 100) {
			if (cnt % 2 == 0) {
				total += cnt;
				System.out.println(cnt + " + " + total + " = " + (cnt + total));
			}
			cnt++;
		}
		System.out.println("1부터 100까지의 짝수의 합 :" + total);

		// 1부터 100까지의 홀수의 합 출력
		cnt = 0;
		total = 0;
		while (cnt <= 100) {
			if (cnt % 2 != 0) {
				total += cnt;
				System.out.println(cnt + " + " + total + " = " + (cnt + total));
			}
			cnt++;
		}
		System.out.println("1부터 100까지의 홀수의 합 :" + total);
		// 2)for문
		int sum = 0, evenSum = 0, oddSum = 0;
		for (int i = 0; i < 100; i++) {
			if (i % 2 == 0) {
				evenSum += i;
			} else if (i % 2 != 0) {
				oddSum += i;
			}
			sum += i;

		}
		System.out.println("1부터 100까지의 합 :" + sum);
		System.out.println("1부터 100까지의 짝수의 합 : " + evenSum);
		System.out.println("1부터 100까지의 홀수의 합 : " + oddSum);
	}

}
