package whileTest;

public class DoWhileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean isTrue = false;
		
//		while (isTrue) {
//			System.out.println("이우진");			
//		}
		
		do {
			System.out.println("이우진");
		} while (isTrue);
		
		
	}

}
