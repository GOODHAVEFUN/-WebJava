package switchTest;

import java.util.Scanner;

public class SwitchTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		String result = null,msg = "1부터 4까지의 정수입력 : ";
		
		System.out.println(msg);
		choice =sc.nextInt();
		
		switch(choice) {
		case 1:
			result = "홀수";
			break;
		case 2:
			result = "짝수";
			break;
		case 3:
			result = "홀수";
			break;
		case 4:
			result = "짝수";
			break;
		case 5:
			result = "잘못입력했습니다";
			break;
		}
		
	}

}
