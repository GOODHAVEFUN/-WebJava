package switchTest;

import java.security.DrbgParameters.NextBytes;
import java.util.Iterator;
import java.util.Scanner;

public class SwitchTask {
	public static void main(String[] args) {
		// 1. 사용자로부터 (1~12)을 입력 받기
		// 2. 입력된 월에 따라 해당하는 계절을 출력받기
		// 12, 1, 2 겨울
		// 3, 4, 5 봄
		// 6, 7, 8 봄
		// 9, 10 ,11 봄
		// 그외는 잘못된 입력입니다

		Scanner sc = new Scanner(System.in);
		int choice = 0;
		String season = null, mounth = "1~12까지 입력받기";

		for (;;) {

			System.out.println(mounth);
			choice = sc.nextInt();

			switch (choice) {
			case 12:
			case 1:
			case 2:
				season = "겨울";
				break;
			case 3:
			case 4:
			case 5:
				season = "봄";
				break;
			case 6:
			case 7:
			case 8:
				season = "여름";
				break;
			case 9:
			case 10:
			case 11:
				season = "가을";
				break;

			default:
				season = "잘못입력한 월";
				break;
			}
			System.out.println("입력한 월은 " + season + "입니다");
		}

	}
}
